-- Databricks notebook source
-- MAGIC %md
-- MAGIC # CSV FILE TABLES

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Circuit File

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_raw

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.circuits;
CREATE TABLE IF NOT EXISTS f1_raw.circuits(
    circuitId INT NOT NULL,
    circuitRef STRING,
    name STRING,
    location STRING,
    country STRING,
    lat DOUBLE,
    lng DOUBLE,
    alt INT,
    url STRING
)
USING csv
OPTIONS (
    path "/mnt/databrick4storageaccount/raw/circuits.csv",
    header "true"
)

-- COMMAND ----------

SELECT * FROM f1_raw.circuits

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Races File

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.races;
CREATE TABLE IF NOT EXISTS f1_raw.races(
    raceId STRING NOT NULL,
    year STRING,
    round STRING,
    circuitId INT,
    name INT,
    date INT,
    time STRING,
    url INT
)
USING csv
OPTIONS (
    path "/mnt/databrick4storageaccount/raw/races.csv",
    header "true"
)

-- COMMAND ----------

SELECT * FROM f1_raw.races

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # JSON FILE TABLES

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.constructors;
CREATE TABLE IF NOT EXISTS f1_raw.constructors(
   ConstructorId INT, ConstructorRef STRING, name STRING, nationality STRING, url STRING
)
USING JSON
OPTIONS (
    path "/mnt/databrick4storageaccount/raw/constructors.json"
)

-- COMMAND ----------

SELECT * FROM f1_raw.constructors

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.driver;
CREATE TABLE IF NOT EXISTS f1_raw.driver(
    driverId INT,
    driverRef STRING,
    number STRING,
    code INT,
    name STRUCT<forename: STRING, surname: STRING>,
    dob Date,
    nationality STRING,
    url STRING
)
USING JSON
OPTIONS (
    path "/mnt/databrick4storageaccount/raw/driver.json"
)

-- COMMAND ----------

SELECT * FROM f1_raw.driver

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.result;
CREATE TABLE IF NOT EXISTS f1_raw.result(
    resultId INT NOT NULL,
    raceId INT,
    driverId INT,
    constructorId INT,
    number FLOAT,
    grid INT,
    position STRING,
    positionText STRING,
    positionOrder INT,
    points FLOAT,
    lap INT,
    time STRING,
    milliseconds INT,
    fastestLap INT,
    rank INT,
    fastestLapTime STRING,
    fastestLapSpeed FLOAT,
    statusId INT
)
USING JSON
OPTIONS (
    path "/mnt/databrick4storageaccount/raw/result.json"
)

-- COMMAND ----------

SELECT * FROM f1_raw.result

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.pitstop;
CREATE TABLE IF NOT EXISTS f1_raw.pitstop(
    raceId INT NOT NULL,
    driverId INT,
    stop_id INT,
    lap_number INT,
    time STRING,
    duration STRING,
    milliseconds INT
)
USING JSON
OPTIONS (
    path "/mnt/databrick4storageaccount/raw/pitstop.json",
    multiLine "true"
)

-- COMMAND ----------

SELECT * FROM f1_raw.pitstop

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # TABLES FOR LIST FILES

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## CSV MULTILINE FILE

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.lap_times;
CREATE TABLE IF NOT EXISTS f1_raw.lap_times(
    raceId INT NOT NULL,
    driverId INT,
    stop_id INT,
    lap_number INT,
    time STRING,
    duration STRING,
    milliseconds INT
)
USING csv
OPTIONS (
    path "/mnt/databrick4storageaccount/raw/lap_times"
)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##MULTILINE JSON FILE

-- COMMAND ----------

DROP TABLE IF EXISTS f1_raw.qualifying;
CREATE TABLE IF NOT EXISTS f1_raw.qualifying(
    qualifyId INT NOT NULL,
    raceId INT,
    driverId INT,
    constructorId INT,
    number STRING,
    position INT,
    q1 STRING,
    q2 STRING,
    q3 STRING
)
USING JSON
OPTIONS (
    path "/mnt/databrick4storageaccount/raw/qualifying",
    multiLine True
)

-- COMMAND ----------

DESC EXTENDED f1_raw.circuits

-- COMMAND ----------

