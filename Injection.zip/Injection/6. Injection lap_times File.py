# Databricks notebook source
# MAGIC %md
# MAGIC #### Injecting Lap_times.csv File

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_data_source", "")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_data", "2021-03-21")
v_file_data = dbutils.widgets.get("p_file_data")

# COMMAND ----------

from pyspark.sql.types import StructType, StringType, IntegerType, StructField
from pyspark.sql.functions import current_timestamp, lit

# COMMAND ----------

time_laps_schema = StructType(fields=[StructField("raceId", IntegerType(), False),
                                    StructField("driverId", IntegerType(), True),
                                    StructField("lap", IntegerType(), True),
                                    StructField("position", IntegerType(), True),
                                    StructField("time", StringType(), True),
                                    StructField("milliseconds", IntegerType(), True)])

# COMMAND ----------

v_file_data


# COMMAND ----------

qualifying_df = spark.read \
            .schema(time_laps_schema)\
            .option("multiLine", True)\
            .csv(f"{raw_folder_path}/{v_file_data}/lap_times")

# COMMAND ----------

display(qualifying_df)

# COMMAND ----------

qualifying_df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Renaming And Add Column

# COMMAND ----------

final_lap_time = qualifying_df.withColumnRenamed("raceId","race_id")\
  .withColumnRenamed("driverId","driver_id")\
  .withColumn("data_source", lit(v_data_source)) \
  .withColumn("file_date", lit(v_file_data))\
  .withColumn("Injection_time", current_timestamp())

# COMMAND ----------

merge_condition= "tgt.result_id = src.result_id  AND src.race_id = tgt.race_id AND tgt.lap = src.lap"
merge_delta_data(final_lap_time, 'f1_processed', 'lap_times', processed_folder_path , merge_condition , 'race_id')

# COMMAND ----------

# MAGIC %sql
# MAGIC -- DROP TABLE f1_processed.lap_times

# COMMAND ----------

dbutils.notebook.exit("Success")