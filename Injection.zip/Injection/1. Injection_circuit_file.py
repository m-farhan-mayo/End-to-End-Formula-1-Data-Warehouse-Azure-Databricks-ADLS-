# Databricks notebook source
# MAGIC %md
# MAGIC ## CSV File

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

dbutils.widgets.text("p_data_source", "")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_data", "2021-03-21")
v_file_data = dbutils.widgets.get("p_file_data")

# COMMAND ----------

v_file_data

# COMMAND ----------

raw_folder_path

# COMMAND ----------

from pyspark.sql.types import IntegerType, StringType, DoubleType, StructField, StructType
from pyspark.sql.functions import lit
from pyspark.sql import DataFrame

# COMMAND ----------

# MAGIC %md
# MAGIC #####StructType Represents The Rows And StructField Represents The Column

# COMMAND ----------

circuit_schema = StructType(fields=[StructField("circuitId", IntegerType(), False),
                                    StructField("circuitRef", StringType(), True),
                                    StructField("name", StringType(), True),
                                    StructField("location", StringType(), True),
                                    StructField("country", StringType(), True),
                                    StructField("lat", DoubleType(), True),
                                    StructField("lng", DoubleType(), True),
                                    StructField("alt", IntegerType(), True),
                                    StructField("url", StringType(), True)])

# COMMAND ----------

circuit_df = spark.read \
    .option("header", "true")\
    .schema(circuit_schema)\
    .csv(f"{raw_folder_path}/{v_file_data}/circuits.csv")

# COMMAND ----------

circuit_df.show(20)

# COMMAND ----------

display(circuit_df)

# COMMAND ----------

circuit_df.printSchema()

# COMMAND ----------

circuit_df.describe().show()

# COMMAND ----------

# MAGIC %md
# MAGIC ##### 2. Select Columns

# COMMAND ----------

circuit_df.select("country").distinct().show()

# COMMAND ----------

circuit_df.select("name","location","circuitRef").show()

# COMMAND ----------

circuit_df.select("name","location","circuitRef").collect()

# COMMAND ----------

select_column_df = circuit_df.select(circuit_df.name.alias("Name"), circuit_df.location, circuit_df.circuitRef)
select_column_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ###### We can use them by creating varibles instead of direct objects

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Renamed Column

# COMMAND ----------

column_renamed_df = circuit_df.withColumnRenamed("circuitId", "Circuit_Id") \
    .withColumnRenamed("circuitRef", "Circuit_Ref") \
    .withColumnRenamed("name", "Name")\
    .withColumnRenamed("location", "Location")\
    .withColumnRenamed("country", "Country")\
    .withColumnRenamed("lat", "Latitude")\
    .withColumnRenamed("lng", "Longitude") \
    .withColumnRenamed("alt", "Altitude")\
    .withColumn("data_source", lit(v_data_source)) \
    .withColumn("file_date", lit(v_file_data))\
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding New Column
# MAGIC
# MAGIC ###### "Lit" used to create a column of literal values

# COMMAND ----------

adding_new_column_df = circuit_df.withColumn("Altitude", circuit_df.alt+1000)\
    .withColumn("DF" , lit("DataFrame"))\
    .show()

# COMMAND ----------

adding_new_column_df = add_injection_date(circuit_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Write Data To Data Lake As Parquet

# COMMAND ----------

circuit_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.circuits")

# COMMAND ----------

dbutils.notebook.exit("Success")