-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_processed
LOCATION "/mnt/databrick4storageaccount/processed"

-- COMMAND ----------

DESC DATABASE f1_processed

-- COMMAND ----------

CREATE DATABASE IF NOT EXISTS f1_presentation
LOCATION "/mnt/databrick4storageaccount/presentation"