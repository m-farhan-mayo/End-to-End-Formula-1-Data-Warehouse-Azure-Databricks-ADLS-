# Databricks notebook source
# MAGIC %md
# MAGIC ### Read Json File Using Spark DataFrame

# COMMAND ----------

# MAGIC %run "../includes/Configuration"

# COMMAND ----------

dbutils.widgets.text("p_data_source", "testing")
v_data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

dbutils.widgets.text("p_file_data", "2021-03-21")
v_file_data = dbutils.widgets.get("p_file_data")

# COMMAND ----------

construtor_schema = "ConstructorId INT, ConstructorRef STRING, name STRING, nationality STRING, url STRING"

# COMMAND ----------

Constructor_df = spark.read \
    .schema(construtor_schema)\
    .json(f"{raw_folder_path}/{v_file_data}/constructors.json")

# COMMAND ----------

display(Constructor_df)

# COMMAND ----------

Constructor_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Drop URL Column 
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

drop_url_df = Constructor_df.drop("url")
drop_url_df.show()

# COMMAND ----------

# MAGIC %md
# MAGIC #### Renamed And Injection Of Columns

# COMMAND ----------

const_final_df = drop_url_df.withColumnRenamed("ConstructorId", "constructor_Id")\
                            .withColumnRenamed("ConstructorRef", "constructor_ref")\
                            .withColumn("Injection_Date", current_timestamp())\
                            .withColumn("data_source", lit(v_data_source)) \
                            .withColumn("file_date", lit(v_file_data))
                            

# COMMAND ----------

display(const_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Write Data Into Parquet

# COMMAND ----------

const_final_df.write.mode("overwrite").format("delta").saveAsTable("f1_processed.constructors")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/databrick4storageaccount/processed/

# COMMAND ----------

dbutils.notebook.exit("Success")