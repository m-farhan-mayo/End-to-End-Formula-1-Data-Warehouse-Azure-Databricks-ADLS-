-- Databricks notebook source
USE f1_presentation

-- COMMAND ----------

SELECT * 
FROM f1_presentation.tot_race_result

-- COMMAND ----------

SELECT driver_name,
 COUNT(1) AS Races,
 SUM(Total_Points) AS Total_Points, 
 AVG(Total_Points) AS Avg_Points
FROM f1_presentation.tot_race_result
GROUP BY driver_name
HAVING COUNT(1) >= 50
ORDER BY Avg_Points DESC

-- COMMAND ----------

SELECT driver_name,
  COUNT(1) AS Races,
  SUM(Total_Points) AS Total_Points, 
  AVG(Total_Points) AS Avg_Points
FROM f1_presentation.tot_race_result
  WHERE year BETWEEN 2010 AND 2020
  GROUP BY driver_name
  HAVING COUNT(1) >= 50
  ORDER BY Avg_Points DESC

-- COMMAND ----------

SELECT constructor_name AS team,
  COUNT(1) AS Races,
  SUM(Total_Points) AS Total_Points, 
  AVG(Total_Points) AS Avg_Points
FROM f1_presentation.tot_race_result
  -- WHERE year BETWEEN 2010 AND 2020
  GROUP BY team
  HAVING COUNT(1) >= 50
  ORDER BY Avg_Points DESC

-- COMMAND ----------

SELECT driver_name ,
  COUNT(1) AS total_races,
  SUM(Total_Points) AS Total_Points, 
  AVG(Total_Points) AS Avg_Points
FROM f1_presentation.tot_race_result
  GROUP BY driver_name
  HAVING COUNT(1) >= 50
  ORDER BY Avg_Points DESC

-- COMMAND ----------

SELECT year, driver_name ,
  COUNT(1) AS total_races,
  SUM(Total_Points) AS Total_Points, 
  AVG(Total_Points) AS Avg_Points,
  RANK() OVER(ORDER BY AVG(Total_Points) DESC) driver_rank
FROM f1_presentation.tot_race_result
  WHERE year BETWEEN 2010 AND 2020
  GROUP BY year, driver_name
  ORDER BY year, Avg_Points DESC

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW Domin_driver
AS
SELECT year, driver_name ,
  COUNT(1) AS total_races,
  SUM(Total_Points) AS Total_Points, 
  AVG(Total_Points) AS Avg_Points,
  RANK() OVER(ORDER BY AVG(Total_Points) DESC) driver_rank
FROM f1_presentation.tot_race_result
  WHERE year BETWEEN 2010 AND 2020
  GROUP BY year, driver_name
  ORDER BY year, Avg_Points DESC

-- COMMAND ----------

-- MAGIC %python
-- MAGIC html = """<h1 style="text-align:center">Report On Dominant Formula 1 Race</h1>"""
-- MAGIC displayHTML(html)

-- COMMAND ----------

