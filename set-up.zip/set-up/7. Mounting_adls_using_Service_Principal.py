# Databricks notebook source
# MAGIC %md
# MAGIC ## Mount Azure Data Lake using Service Principal
# MAGIC #### Steps to follow
# MAGIC 1. Get Client_id, tenat_id, Client_secret from key vault.
# MAGIC 2. Set Spark Config with App/ Client Id, Directory/ Tenant Id & Secret
# MAGIC 3. Call File System utility mount to mount storage.
# MAGIC 4. Explore Other system File Utilities related to mount (list all mounts, unmounts)

# COMMAND ----------

dbutils.secrets.listScopes()


# COMMAND ----------

scopes = dbutils.secrets.listScopes()
print(scopes)

# COMMAND ----------

secrets = dbutils.secrets.list(scope="formula1-scope")
print(secrets)

# COMMAND ----------

storage_account_name = "databrick4storageaccount"
client_id = dbutils.secrets.get(scope="formula1-scope", key="formula1-app-client-id")
tenat_id = dbutils.secrets.get(scope="formula1-scope", key="formula1-app-tenat-id")
client_secret = dbutils.secrets.get(scope="formula1-scope", key="formula1-app-client-secret")

# COMMAND ----------

configs = {
    "fs.azure.account.auth.type": "OAuth",
    "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
    "fs.azure.account.oauth2.client.id": client_id ,
    "fs.azure.account.oauth2.client.secret": client_secret,
    "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenat_id}/oauth2/token"}

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://raw@databrick4storageaccount.dfs.core.windows.net/",
  mount_point = f"/mnt/databrick4storageaccount/raw",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://processed@databrick4storageaccount.dfs.core.windows.net/",
  mount_point = f"/mnt/databrick4storageaccount/processed",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://presentation@databrick4storageaccount.dfs.core.windows.net/",
  mount_point = f"/mnt/databrick4storageaccount/presentation",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://demos@databrick4storageaccount.dfs.core.windows.net/",
  mount_point = f"/mnt/databrick4storageaccount/demos",
  extra_configs = configs)

# COMMAND ----------

# mount_adls("raw")

# COMMAND ----------

# mount_adls("processed")

# COMMAND ----------

# mount_adls("presentation")

# COMMAND ----------

display(dbutils.fs.ls("mnt/databrick4storageaccount/raw"))

# COMMAND ----------

dbutils.fs.ls("mnt/databrick4storageaccount/presentation")

# COMMAND ----------

dbutils.fs.ls("mnt/databrick4storageaccount/processed")

# COMMAND ----------

dbutils.fs.ls("mnt/databrick4storageaccount/demos")

# COMMAND ----------

display(spark.read.csv("/mnt/databrick4storageaccount/demo/circuits.csv"))

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

dbutils.fs.unmount("/mnt/databrick4storageaccount/raw") #For Unmounting The Data

# COMMAND ----------

dbutils.fs.unmount("/mnt/databrick4storageaccount/processed") #For Unmounting The Data

# COMMAND ----------

dbutils.fs.unmount("/mnt/databrick4storageaccount/presentation") #For Unmounting The Data