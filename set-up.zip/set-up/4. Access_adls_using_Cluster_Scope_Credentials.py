# Databricks notebook source
# MAGIC %md
# MAGIC #### Access Azure Data Lake using Cluster Scope Credentials
# MAGIC 1. Set the spark config fs.azure.account.key
# MAGIC 1. List files from demo container
# MAGIC 1. Read data from circuits.csv files.

# COMMAND ----------

spark.conf.set(
    "fs.azure.account.key.databrick4storageaccount.dfs.core.windows.net",
    "jclHbqqs1nVTgZSsZU4szCMIR22j/Vxm0lMEzSGc0PzSss+39KK3HjgkTtlkhstL4wvxN5fmTC73+AStgMdlsQ=="
)

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@databrick4storageaccount.dfs.core.windows.net"))

# COMMAND ----------

dbutils.fs.ls("abfss://demo@databrick4storageaccount.dfs.core.windows.net")

# COMMAND ----------

display(spark.read.csv("abfss://demo@databrick4storageaccount.dfs.core.windows.net/circuits.csv"))

# COMMAND ----------

