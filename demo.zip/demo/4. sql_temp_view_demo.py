# Databricks notebook source
# MAGIC %run "../includes/Configuration"

# COMMAND ----------

race_result_df = spark.read.parquet(f"{presentation_folder_path}/race_results")

# COMMAND ----------

race_result_df.createOrReplaceTempView("v_race_result")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(1)
# MAGIC FROM v_race_result
# MAGIC WHERE year = 2020

# COMMAND ----------

race_result_2019_df = spark.sql("SELECT * FROM v_race_result WHERE year = 2019")

# COMMAND ----------

display(race_result_2019_df)

# COMMAND ----------

p_race_year = 2018

# COMMAND ----------

race_result_2019_df = spark.sql(f"SELECT * FROM v_race_result WHERE year = {p_race_year}")

# COMMAND ----------

display(race_result_2019_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Global Temp View
# MAGIC ##### Use in other notebooks also

# COMMAND ----------

race_result_df.createOrReplaceGlobalTempView("gv_race_result")

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES IN global_temp

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM global_temp.gv_race_result