# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS f1_demos
# MAGIC LOCATION "/mnt/databrick4storageaccount/demos"

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demos.results_managed

# COMMAND ----------

results_df = spark.read \
.option("inferSchema", True) \
.json("/mnt/databrick4storageaccount/raw/2021-03-28/results.json")

# COMMAND ----------

results_df.write.format("delta") \
    .option("mergeSchema", "true") \
    .mode("overwrite") \
    .saveAsTable("f1_demos.results_managed")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_managed

# COMMAND ----------

results_df.write.format("delta") \
    .option("mergeSchema", "true") \
    .mode("overwrite") \
    .save("/mnt/databrick4storageaccount/demos/results_external")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demos.results_external
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/databrick4storageaccount/demos/results_external"
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_external

# COMMAND ----------

results_external_df = spark.read.format("delta").load("/mnt/databrick4storageaccount/demos/results_external")

# COMMAND ----------

display(results_external_df)

# COMMAND ----------

results_df.write.format("delta") \
    .option("mergeSchema", "true") \
    .mode("overwrite") \
    .partitionBy("constructorId")\
    .saveAsTable("f1_demos.results_partitioned")

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW PARTITIONS f1_demos.results_partitioned

# COMMAND ----------

# MAGIC %md
# MAGIC UPDATE & DELETE IN DELTA LAKE

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_managed

# COMMAND ----------

# MAGIC %sql
# MAGIC UPDATE f1_demos.results_managed
# MAGIC   SET points = 11 - position
# MAGIC   WHERE position <= 10
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_managed

# COMMAND ----------

from delta.tables import DeltaTable

deltaTable = DeltaTable.forPath(spark, "/mnt/databrick4storageaccount/demos/results_external")
deltaTable.update("position <= 10", {"points" : "21 - position"})

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_external

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM f1_demos.results_managed
# MAGIC WHERE position > 10

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_managed

# COMMAND ----------

from delta.tables import DeltaTable

deltaTable = DeltaTable.forPath(spark, "/mnt/databrick4storageaccount/demos/results_external")
deltaTable.delete("points = 0")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_external

# COMMAND ----------

# MAGIC %md
# MAGIC UPSERT USING MERGE IN DELTA LAKE
# MAGIC

# COMMAND ----------

driver_day1_df = spark.read \
  .option("inferSchema", True)\
  .json("/mnt/databrick4storageaccount/raw/2021-03-28/drivers.json")\
  .filter("driverId <= 10")\
  .select("driverId", "dob", "name.forename", "name.surname")

# COMMAND ----------

display(driver_day1_df)

# COMMAND ----------

from pyspark.sql.functions import upper

driver_day2_df = spark.read \
  .option("inferSchema", True)\
  .json("/mnt/databrick4storageaccount/raw/2021-03-28/drivers.json")\
  .filter("driverId BETWEEN 6 AND 15")\
  .select("driverId", "dob", upper("name.forename").alias("forename"), upper("name.surname").alias("name.surname"))

# COMMAND ----------

display(driver_day2_df)

# COMMAND ----------

from pyspark.sql.functions import upper

driver_day3_df = spark.read \
  .option("inferSchema", True)\
  .json("/mnt/databrick4storageaccount/raw/2021-03-28/drivers.json")\
  .filter("driverId BETWEEN 1 AND 5 OR driverId BETWEEN 15 AND 20")\
  .select("driverId", "dob", upper("name.forename").alias("name.forename"), upper("name.surname").alias("name.surname"))

# COMMAND ----------

display(driver_day3_df)

# COMMAND ----------

driver_day1_df.createOrReplaceTempView("driver_day1")

# COMMAND ----------

driver_day2_df.createOrReplaceTempView("driver_day2")

# COMMAND ----------

driver_day3_df.createOrReplaceTempView("driver_day3")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demos.results_merge(
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createdDate DATE,
# MAGIC   updatedDate DATE
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %md
# MAGIC DAY 1
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demos.results_merge tgt
# MAGIC USING driver_day1 upd
# MAGIC On tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET tgt.dob = upd.dob,
# MAGIC              tgt.forename = upd.forename,
# MAGIC              tgt.surname = upd.surname,
# MAGIC              tgt.updatedDate = current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (driverId, dob, forename, surname, createdDate) VALUES (driverId, dob, forename, surname, current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_merge

# COMMAND ----------

# MAGIC %md
# MAGIC DAY 2
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demos.results_merge tgt
# MAGIC USING driver_day2 upd
# MAGIC ON tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET tgt.dob = upd.dob,
# MAGIC              tgt.forename = upd.forename,
# MAGIC              tgt.surname = upd.`name.surname`,
# MAGIC              tgt.updatedDate = current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (driverId, dob, forename, surname, createdDate) 
# MAGIC        VALUES (upd.driverId, upd.dob, upd.forename, upd.`name.surname`, current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_merge

# COMMAND ----------

# MAGIC %md
# MAGIC DAY 3

# COMMAND ----------

# MAGIC %md
# MAGIC USING PYTHON 
# MAGIC

# COMMAND ----------

# from delta.tables import DeltaTable
# from pyspark.sql.functions import current_date

# deltaTable = DeltaTable.forPath (spark, "/mnt/databrick4storageaccount/demos/drivers_merge")

# deltaTable.alias("tgt").merge(
#     driver_day3_df.alias ("upd"),
#     "tgt.driverId= upd.driverId") \
#     .whenMatchedUpdate (set = { "tgt.dob": "upd.dob",
#                                "tgt.name.forename": "upd.`name.forename`",
#                                "tgt.name.surname": "upd.`name.surname`",
#                                "updatedDate": "current_date()" })\
#     .whenNotMatchedInsert(values =
#                             {"tgt.dob": "upd.dob",
#                              "tgt.name.forename": "upd.`name.forename`",
#                              "tgt.name.surname": "upd.`name.surname`",
#                              "createdDate": "current_date()"})\
#     .execute()


# COMMAND ----------

# MAGIC %md
# MAGIC USING SQL

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demos.results_merge tgt
# MAGIC USING driver_day3 upd
# MAGIC ON tgt.driverId = upd.driverId
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET tgt.dob = upd.dob,
# MAGIC              tgt.forename = upd.`name.forename`,
# MAGIC              tgt.surname = upd.`name.surname`,
# MAGIC              tgt.updatedDate = current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (driverId, dob, forename, surname, createdDate) 
# MAGIC        VALUES (upd.driverId, upd.dob, upd.`name.forename`, upd.`name.surname`, current_timestamp)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_merge

# COMMAND ----------

# MAGIC %md
# MAGIC 1. History & Visioning
# MAGIC 2. Time Travel
# MAGIC 3. Vaccum

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC HISTORY f1_demos.results_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_merge VERSION AS OF 3

# COMMAND ----------

df = spark.read.format("delta").option("VERSION", "3").load("/mnt/databrick4storageaccount/demos/drivers_merge")

# COMMAND ----------

display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC VACUUM f1_demos.results_merge RETAIN 168 HOURS

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_merge VERSION AS OF 3

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM f1_demos.results_merge WHERE driverId = 1

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM f1_demos.results_merge

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_demos.drivers_merge tgt
# MAGIC USING f1_demos.drivers_merge VERSION AS OF 2 src
# MAGIC   ON (tgt.driverId = src.driverId)
# MAGIC WHEN NOT MATCHED THEN
# MAGIC   INSERT *

# COMMAND ----------

# MAGIC %md
# MAGIC Transcation Logs

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demos.drivers_txn (
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createdDate DATE,
# MAGIC   updatedDate DATE
# MAGIC )
# MAGIC USING DELTA

# COMMAND ----------

# MAGIC %sql
# MAGIC DESC HISTORY f1_demos.drivers_txn

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO f1_demos.drivers_txn
# MAGIC SELECT * FROM f1_demos.results_merge
# MAGIC WHERE driverId = 3

# COMMAND ----------

# MAGIC %sql
# MAGIC DELETE FROM f1_demos.drivers_txn
# MAGIC WHERE driverId = 2

# COMMAND ----------

for driver_id in range(3, 20):
    spark.sql(f"""INSERT INTO f1_demos.drivers_txn
              SELECT * FROM f1_demos.results_merge
              WHERE driverId = {driver_id}""")

# COMMAND ----------

# MAGIC %md
# MAGIC Convert PARQUET TO DELTA
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f1_demos.drivers_convert_to_delta (
# MAGIC   driverId INT,
# MAGIC   dob DATE,
# MAGIC   forename STRING,
# MAGIC   surname STRING,
# MAGIC   createdDate DATE,
# MAGIC   updatedDate DATE
# MAGIC )
# MAGIC USING PARQUET

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO f1_demos.drivers_convert_to_delta
# MAGIC SELECT * FROM f1_demos.results_merge
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CONVERT TO DELTA f1_demos.drivers_convert_to_delta

# COMMAND ----------

df = spark.table("f1_demos.drivers_convert_to_delta")

# COMMAND ----------

df.write.format("parquet").save("/mnt/databrick4storageaccount/demos/drivers_convert_to_delta_new")

# COMMAND ----------

# MAGIC %sql
# MAGIC CONVERT TO DELTA parquet.`/mnt/databrick4storageaccount/demos/drivers_convert_to_delta_new`

# COMMAND ----------

