-- Databricks notebook source
USE f1_processed

-- COMMAND ----------

SELECT *, CONCAT(driver_ref, "-", nationality) AS new_drivers_ref
FROM drivers

-- COMMAND ----------

SELECT *, SPLIT(name, " ")[0] forename,SPLIT(name, " ")[0] surname
FROM drivers

-- COMMAND ----------

SELECT *, current_timestamp
FROM drivers

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ######## to get the date according to the format 
-- MAGIC SELECT *, date_format(dob, "yyyy-MM-dd")
-- MAGIC
-- MAGIC FROM drivers

-- COMMAND ----------

SELECT COUNT(1) FROM drivers

-- COMMAND ----------

SELECT MAX(number) FROM drivers

-- COMMAND ----------

SELECT * FROM drivers WHERE number = 99


-- COMMAND ----------

SELECT nationality, COUNT(1) 
FROM drivers 
GROUP BY nationality
HAVING COUNT(*)>100
ORDER BY nationality

-- COMMAND ----------

-- MAGIC %md
-- MAGIC WINDOW FUNCTION

-- COMMAND ----------

SELECT nationality, name, driver_id, RANK() OVER (PARTITION BY nationality ORDER BY nationality DESC) as age_rank
FROM drivers
ORDER BY nationality, age_rank

-- COMMAND ----------

