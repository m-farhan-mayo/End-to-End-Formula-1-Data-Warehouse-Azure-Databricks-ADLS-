# Databricks notebook source
# MAGIC %run "../includes/Configuration"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregate Function Demo
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Built-In Aggregate Functions
# MAGIC

# COMMAND ----------

race_result_df = spark.read.parquet(f"{processed_folder_path}/races")

# COMMAND ----------

display(race_result_df)

# COMMAND ----------

from pyspark.sql.functions import count, countDistinct, sum

# COMMAND ----------

# MAGIC %md
# MAGIC Distinct Function

# COMMAND ----------

race_result_df.select(countDistinct("raceId")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC Count Function

# COMMAND ----------

race_result_df.select(count("raceId")).show()

# COMMAND ----------

# MAGIC %md
# MAGIC Sum Function

# COMMAND ----------

#race_result_df.filter("name == 'Lewis Hamilton'").select(sum("points"), countDistinct("race_name"))\
  #  .withColumnRenamed("sum(points)", "total_points").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Group BY

# COMMAND ----------

race_result_df\
    .groupBy("name")\
    .sum("year")\
    .show()

# COMMAND ----------

# MAGIC %md
# MAGIC Window Function

# COMMAND ----------

race_demo = race_result_df.filter(race_result_df.year.isin([2019, 2020]))  

# COMMAND ----------

demo_group_df = race_demo\
    .groupBy("raceId", "name")\
    .agg(sum("year").alias("total_years"), countDistinct("raceId").alias("total_races"))

# COMMAND ----------

display(demo_group_df)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import rank, desc


DriverRankSpec = Window.partitionBy("total_years").orderBy(desc("raceId"))
demo_group_df = demo_group_df.withColumn("driver_rank", rank().over(DriverRankSpec))
display(demo_group_df)

# COMMAND ----------

display(DriverRankSpec)

# COMMAND ----------

