# Databricks notebook source
raw_folder_path = "/mnt/databrick4storageaccount/raw"
processed_folder_path = "/mnt/databrick4storageaccount/processed"
presentation_folder_path = "/mnt/databrick4storageaccount/presentation"