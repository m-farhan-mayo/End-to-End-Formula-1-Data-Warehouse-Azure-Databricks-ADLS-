# Databricks notebook source
# MAGIC %run "../includes/Configuration"

# COMMAND ----------

dbutils.widgets.text("p_file_data", "2021-03-21")
v_file_data = dbutils.widgets.get("p_file_data")

# COMMAND ----------

spark.sql("""
          CREATE TABLE IF NOT EXISTS f1_presentation.calculated_race_results(
              race_year INT,
              team_name STRING,
              driver_id INT,
              driver_name STRING,
              race_id INT,
              position INT,
              points INT,
              calculated_points INT,
              created_date TIMESTAMP,
              updated_date TIMESTAMP
              ) USING DELTA
          """)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE f1_presentation.tot_race_result
# MAGIC USING PARQUET
# MAGIC AS
# MAGIC SELECT races.year,
# MAGIC        constructors.name AS constructor_name,
# MAGIC        drivers.name AS driver_name,
# MAGIC        results.position,
# MAGIC        results.points,
# MAGIC        11 - results.position AS Total_Points
# MAGIC FROM f1_processed.results
# MAGIC JOIN f1_processed.drivers ON (results.driver_id = drivers.driver_id)
# MAGIC JOIN f1_processed.constructors ON (results.constructor_id = constructors.constructor_id)
# MAGIC JOIN f1_processed.races ON (results.race_id = races.raceId)
# MAGIC WHERE results.position <= 10

# COMMAND ----------

spark.sql("""
CREATE OR REPLACE TEMP VIEW race_result_updates
AS
SELECT races.year,
       constructors.name AS constructor_name,
       drivers.driver_id,
       drivers.name AS driver_name,
       races.raceId,
       results.position,
       results.points,
       11 - results.position AS Total_Points
FROM f1_processed.results
JOIN f1_processed.drivers ON (results.driver_id = drivers.driver_id)
JOIN f1_processed.constructors ON (results.constructor_id = constructors.constructor_id)
JOIN f1_processed.races ON (results.race_id = races.raceId)
WHERE results.position <= 10
  AND results.file_date = "{v_file_data}"
  """)

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO f1_presentation.tot_race_result tgt
# MAGIC USING race_result_updates upd
# MAGIC ON (tgt.driver_id = upd.driver_id AND tgt.race_id = upd.race_id)
# MAGIC WHEN MATCHED THEN
# MAGIC   UPDATE SET tgt.position = upd.position,
# MAGIC              tgt.points = upd.points ,
# MAGIC              tgt.calculated_points = upd.calculated_points,
# MAGIC              tgt.updated_date = current_timestamp
# MAGIC WHEN NOT MATCHED
# MAGIC   THEN INSERT (race_year, team_name, driver_id, driver_name, race_id, position, points,calculated_points,created_date ) 
# MAGIC        VALUES (race_year, team_name, driver_id, driver_name, race_id, position, points,calculated_points, current_timestamp)